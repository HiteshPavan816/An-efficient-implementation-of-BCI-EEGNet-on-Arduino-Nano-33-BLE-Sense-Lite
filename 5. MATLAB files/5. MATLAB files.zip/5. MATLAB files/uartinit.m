function [device] = uartinit(comstring,baudrate,timeout)
    % This function initializes serial communication
   
    device = serialport(comstring,baudrate,"Timeout",timeout);
end