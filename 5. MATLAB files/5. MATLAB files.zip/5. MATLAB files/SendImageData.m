function [err] = SendImageData(device,header,data,footer)
    % This function reads the 16-bit packed fixed point input data and 
    % unpacks the read data and sends the two bytes of all the 9060 
    % datapoints (i.e., 18120 Bytes) to Arduino through UART


    data_len = length(data);
    % Unpack the input data
    data1 = [uint8(bitshift(bitand(uint16(data),0xFF00),-8)), uint8(bitshift(bitand(uint16(data),0x00FF),0))];
    data =[];

    % Put the two unpacked bytes of a data point together
    for i =1:data_len
        data = [data,data1(i),data1(i+data_len)];
    end
    
    % Unpack the length (Number of Bytes to be sent)
    [~,packetlength] = size(data);
    packetlengtth4 = uint8(bitshift(bitand(packetlength,0xFF000000),-24));
    packetlengtth3 = uint8(bitshift(bitand(packetlength,0x00FF0000),-16));
    packetlengtth2 = uint8(bitshift(bitand(packetlength,0x0000FF00),-8));
    packetlengtth1 = uint8(bitshift(bitand(packetlength,0x000000FF),0));
    
    % Data to be sent
    datasent = [header packetlengtth4 packetlengtth3 packetlengtth2 packetlengtth1];
    
    % Send the data to Arduino
    write(device,datasent,"uint8");
    i=0;
    count = 0;

    while (i==0)
        % Read sent acknowledment from arduino
        readdata = read(device,1,"uint8");   
        if(readdata == 0x11)
            % If sent acknowledgemnt is recieved, then send the unpacked data
            datasent1 = [data footer];
            write(device,datasent1,"uint8");                   
            err=0;
            i=1;
            break;
        else
            % if acknowledment did not recieved, then wait for some time
            pause(0.001);
            count=count+1;
            if(count>2000)
                err=-1;
                i=1;
                break;
            end
        end 
    end
end