clear;clc;close all;
%% Access the input dataset
f1 = csvread('mne_input_data_withoutIIR.csv');
[row,col]=size(f1);

% Fixed point conversion
f3 = fi(f1,1,16,15);
f2 = str2num(fi(f1,1,16,15).dec);

% Storing the fixed point converted data
writematrix(f2,'Xtest_fixedpoint.csv');

% Two's compliment of data
f2(f2>32767) = f2(f2>32767) - 65536;


%% Filtering the input data for noise removal
%5th order Elliptic IIR filter
%Filter coefficients
a = [ 1.000000000000000  -4.471134638355548   8.001513786737616  -7.156132474050281   3.193956589312181  -0.568033365047141];
b = [ 0.762826106083000  -3.811672058064143   7.620887262604240  -7.620887262604240   3.811672058064143  -0.762826106083000];

x = [zeros(288, 5), f2(:,1:col-1)];
y = [zeros(size(x))];
k = 1:row;
for n = 6:col+5-1
    y(k,n) = -a(2)*(y(k,n-1)) -a(3)*(y(k,n-2)) -a(4)*(y(k,n-3))  ...
            - a(5)*(y(k,n-4)) -a(6)*(y(k,n-5)) + b(1)*(x(k,n)) ...
            + b(2)*(x(k,n-1)) + b(3)*(x(k,n-2)) + b(4)*(x(k,n-3)) ...
           +  b(5)*(x(k,n-4)) + b(6)*(x(k,n-5));    
end


%% Quantization
input_qscale = 0.0008163931197486818*(2^15);
input_zero_point = -24;
y_quant = y / input_qscale + input_zero_point;
y_q8 = int8(y_quant);