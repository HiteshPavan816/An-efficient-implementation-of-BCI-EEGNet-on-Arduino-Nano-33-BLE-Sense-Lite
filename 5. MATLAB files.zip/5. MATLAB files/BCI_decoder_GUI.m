%% E1-201 : Hardware Acceleration on Machine Learning
%
% Course Project : 
% 
% Project Title  : An efficient implementation of Brain Computer Interface(BCI EEGNet) decoder on Arduino Nano 33 BLE sense Lite
% 
% Authors :
%           1. Hitesh Pavan Oleti (SR.No.:19804, ESE, IISc)
%           2. Anand Chauhan      (SR.No.:*****, ESE, IISc)
% 
% Submitted to :
% Prof. Chetan Singh Thakur,
% NeuRonICS Lab, IISc.
%
%% GUI for Brain Computer Interface(BCI) decoder
%
%

close all;clear all;clc
% Get the screen size
screen_size = get(0, 'ScreenSize');

% Create a figure window with full-screen size
global f;
f = figure('Name', 'BCI EEG-NET', 'Position', [90, 85, 1280, 660]);

% Remove the text bar, menu bar, and toolbar, and create a standalone window
set(f, 'MenuBar', 'none', 'ToolBar', 'none', 'NumberTitle', 'off', 'Name', '');

% Create a push button, a text field, and an image
string = "Run all dataset";
button1 = uicontrol('Style', 'pushbutton', 'String', string, 'FontSize', 12, ...
    'Position', [50 250 200 40]);

button2 = uicontrol('Style', 'pushbutton', 'String', 'Select a Sample', 'FontSize', 12, ...
    'Position', [50 380 200 40]);

button3 = uicontrol('Style', 'pushbutton', 'String', 'Model Statistics', 'FontSize', 12, ...
    'Position', [50 120 200 40]);

% textbox = uicontrol('Style', 'edit', 'Position', [10 50 100 30]);

text1 = uicontrol('Style', 'text', 'String', 'E1 201: HAOML 2022 Course Project', 'Position', [300 600 600 30],...
  'FontSize', 18, 'FontWeight', 'bold');
text2 = uicontrol('Style', 'text', 'String', 'An efficient implementation of BCI EEG net architecture ', ...
    'Position', [300 560 600 30],...
    'ForegroundColor', "red", 'FontSize', 18, 'FontWeight', 'bold');

% Set the callback function for the button
set(button1, 'Callback', @give_all_samples);
set(button2, 'Callback', @give_one_sample);
set(button3, 'Callback', @model_stats);

% Load an image file using the imread function
image = imread('logo.png');

% Display the image in the figure at position (100,100) with size 200x200
[x,map]=imread('logo.png');
I2=imresize(x, [60 226]);
h=uicontrol('style','pushbutton','units','pixels', 'position',[1020 580 226 60],'cdata',I2);