function model_stats(hObject, eventdata)
    % This function displays the BCI decoder model statatistics.

    % Clean the GUI while starting a function
    try
        global text_2;global text_3;global text_4;
        global text_5;global text_6;global text_7;
        global text_8;global bb;global ax1
        set(text_2, 'Visible','off');set(text_3,'Visible','off');
        set(text_4, 'Visible','off');
        set(text_5,'Visible','off');set(text_6,'Visible','off');
        set(text_7,'Visible','off');set(text_8,'Visible','off');
        set(bb,'Visible','off');set(ax1,'Visible','off');        
    catch
        disp('');
    end

    % display The BCI decoder model statatistics.
    global h1;
    [x1,map1]=imread('ml_model.jpg');
    I21=imresize(x1, [360 700]);    
    h1 = uicontrol('style','pushbutton','units','pixels','position',[350 85 700 360],'cdata',I21);
end