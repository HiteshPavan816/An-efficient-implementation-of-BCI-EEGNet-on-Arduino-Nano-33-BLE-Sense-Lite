function give_one_sample(hObject, eventdata)
    % This function tests BCI decoder for a selected test sample and returns the
    % predicted class.

    % Initializing serial communication
    clc;
    serialportlist("available");
    [device] = uartinit("COM21",115200,1);
    
    % Clean the GUI while starting a function
    try
        global text_2;global text_3;global text_4;
        global text_5;global text_6;global text_7;
        global text_8;global bb;global ax1;global h1;
        set(h1,'Visible','off');set(text_2, 'Visible','off');
        set(text_3,'Visible','off');set(text_4, 'Visible','off');
        set(text_5,'Visible','off');set(text_6,'Visible','off');
        set(text_7,'Visible','off');set(text_8,'Visible','off');
        set(bb,'Visible','off');set(ax1,'Visible','off');        
    catch
        disp('');
    end

    % Browsing a csv file
    [file_name, folder_name] = uigetfile('*.csv'); 

    % Reading data from the selected .csv file
    data = csvread(strcat(folder_name,file_name));    
    labels = data(end-3:end);
    data = data(1:end-4);

    global f;
    % Output classes
    label_text = [" Audio Left", " Audio Right", " Visual Left", " Visual Right"];

    % Scale and bias for post processing (to get the actual predicted
    % valuesof the four classes
    output_scale = 0.00390625;
    output_zero_point = -128;
    
    
    % Show running status on GUI while sending data to UART and doing
    % computations on Arduino
    text_1 = uicontrol(f,'Style', 'text', 'String', 'Running......', 'Position', ...
            [550 495 100 30],'FontSize', 16, 'FontWeight', 'bold');   
        
    flag=0;
    while(1)
        % Break if sample is given
        if(flag ~= 0)
            break;
        end

        % Sending Data to Arduino
        fprintf("Data sent to arduino (%s-row) : ",file_name(1:end-4));        
        fprintf("%d, %d, %d, %d,....\n\n",data(1:4));        
        [err] = SendImageData(device,[0xCC 0x33], data ,[0xAA 0x55]);
                
        % Reading Data from Arduino
        readdata=[];
        count=0;
        while(size(readdata,2)==0)            
            %Read Predicted classes from Arduino
            readdata = read(device,4,"uint8");            
            count=count+1;
            pause(.001);
            if(count>2000)
                break;
            else
                % Clear and reassign  the PORT incase of time-out error
                if(isempty(readdata))
                    clear device;
                    serialportlist("available");
                    [device] = uartinit("COM21",115200,1);                 
                else
                    flag = 1;
                    % Two's complement on read data
                    readdata(readdata>127) = readdata(readdata>127)-256;
                    fprintf("Predicted labels (by Arduino) : ");
                    fprintf("[ %d , %d , %d , %d ] --> [ %d , %d , %d , %d] \n\n",readdata,(readdata == max(readdata)));
                    fprintf("Actual labels of %sth row : ",file_name(1:end-4));disp(labels);
                    
                    if(sum(labels == (readdata == max(readdata))) == 4)
                        fprintf("Status : Correctly classified\n");
                    else 
                        fprintf("Status : Misclassified\n");
                    end
                    fprintf('\n********************************************************************************\n');
    

                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%<<<<<<GUI code starts here>>>>>>%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                    

                    % Erase the 'Running...' text on GUI
                    set(text_1,'Visible','off');
    
                    % Predicted and actual classes
                    pred_class = label_text(find(readdata == max(readdata)));
                    act_class      = label_text(find(labels));
                                                       
                    try
                        % Text fields
                        global text_5;global text_6;global text_7;global text_8;

                        text_5 = uicontrol(f,'Style', 'text', 'String',strcat('Sample Number   = ',sprintf(" %s", file_name(1:end-4))),...
                        'Position', [350 415 300 30],'FontSize', 11, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
                     
                        text_6 = uicontrol(f, 'Style', 'text', 'String',strcat('Actual Class          = ',act_class),...
                        'Position', [350 385 300 30],'FontSize', 11, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
                     
                        if(sum(labels == (readdata == max(readdata))) == 4)
                            color_string = "g";
                        else
                            color_string = "r";
                        end
                        text_7 = uicontrol(f, 'Style', 'text', 'String',strcat('Predicted Class    =               ',pred_class),...
                        'Position', [350 355 300 30], 'FontSize', 11, 'FontWeight', 'bold', 'HorizontalAlignment', 'left','ForegroundColor',color_string);
                        
                        text_8 = uicontrol(f, 'Style', 'text', 'String','Predicted Class    = ',...
                        'Position', [350 355 140 30], 'FontSize', 11, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
                       
                        % BAR chart
                        X = categorical({'Audio Left', 'Audio Right', 'Visual Left', 'Visual Right'});
                        X = reordercats(X,{'Audio Left', 'Audio Right', 'Visual Left', 'Visual Right'});
                        Y = ((readdata - output_zero_point) * output_scale)*100;    
                        [Max,Index] = max(Y);
                        
                        global bb
                        global ax1
                        ax1 = axes(f, 'Position',[0.3 0.2 0.6 0.3]);
                        bb = bar(ax1,X, Y,'FaceColor','flat');
                        bb.CData(Index,:) = [0 0.8 0.8];
                        ylim([0 100]);
                    catch
                        disp("Figure is closed");
                        break;
                    end 
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%<<<<<<GUI code ends here>>>>>>%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                end
                break;
            end
        end   
    end

    clear device;
end