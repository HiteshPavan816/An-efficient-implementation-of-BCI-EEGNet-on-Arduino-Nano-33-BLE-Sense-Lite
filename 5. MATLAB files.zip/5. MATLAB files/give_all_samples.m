function give_all_samples(hObject, eventdata)
    % This function tests BCI decoder for all the test data and returns the
    % number of correctly classified data samples and the overall testing 
    % accuracy. 
    
    % Initializing serial communication
    serialportlist("available");
    [device] = uartinit("COM21",115200,1);
    
    % Reading fixedpoint input (not preprocessed)
    data = csvread('Xtest_fixedpoint.csv');
    data = data(218:end,1:end-1);    
    labels = csvread('quantized_int8_Xtest.csv');
    labels = labels(:,end-3:end);
    
    k=1;success = 0; 
    global f 
    
    % Show running status on GUI while sending data to UART and doing
    % computations on Arduino
    text_1 = uicontrol(f,'Style', 'text', 'String', 'Running......', 'Position', ...
            [550 495 100 30],'FontSize', 16, 'FontWeight', 'bold');   

    % Clean the GUI while starting a function
    try
        global text_2;global text_3;global text_4;
        global text_5;global text_6;global text_7;
        global text_8;global bb;global ax1;global h1;
        set(h1,'Visible','off');set(text_2, 'Visible','off');
        set(text_3,'Visible','off');set(text_4, 'Visible','off');
        set(text_5,'Visible','off');set(text_6,'Visible','off');
        set(text_7,'Visible','off');set(text_8,'Visible','off');
        set(bb,'Visible','off');set(ax1,'Visible','off');        
    catch
        disp('');
    end

    % Output classes
    label_text = [" Audio Left", " Audio Right", " Visual Left", " Visual Right"];

    % Scale and bias for post processing (to get the actual predicted
    % valuesof the four classes
    output_scale = 0.00390625;
    output_zero_point = -128;


    while(1)
        %Break if all samples are over
        if(k>71)
            break;
        end        
    
        % Send data to Arduino
        X_test = data(k,:);
        fprintf("Data sent to arduino (%d-row) : ",k);        
        fprintf("%d, %d, %d, %d,....\n\n",X_test(1:4));    
        [err] = SendImageData(device,[0xCC 0x33], X_test ,[0xAA 0x55]);
            

        readdata=[];
        count=0;
        while(size(readdata,2)==0)
            %Read Predicted classes from Arduino
            readdata = read(device,4,"uint8");            
            count=count+1;
            pause(.001);
            if(count>2000)
                break;
            else
                % Clear and reassign  the PORT incase of time-out error
                if(isempty(readdata))
                    %warning('\nTimeout error\n');
                    clear device;
                    serialportlist("available");
                    [device] = uartinit("COM21",115200,1);                 
                else
                    % Two's complement on read data
                    readdata(readdata>127) = readdata(readdata>127)-256;
                    fprintf("Predicted labels (by Arduino) : ");
                    fprintf("[ %d , %d , %d , %d ] --> [ %d , %d , %d , %d] \n\n",readdata,(readdata == max(readdata)));
                    fprintf("Actual labels of %dth row : ",k);disp(labels(k,:));
                    
                    %Finding success ratio
                    if(sum(labels(k,:) == (readdata == max(readdata))) == 4)
                        success = success + 1;
                        fprintf("Status : Correctly classified\n");
                    else 
                        fprintf("Status : Misclassified\n");
                    end
                    fprintf("\nSuccess : %d",success);
                    fprintf('\n********************************************************************************\n');
        

                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%<<<<<<GUI code starts here>>>>>>%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % Get the value from the text box                   
                    if(k==1)
                        set(text_1,'Visible','off');
                    end

                    total_test_points = 71;                    

                    %Predicted and actual labels; Accuracy
                    pred_class = label_text(find(readdata == max(readdata)));
                    class      = label_text(find(labels(k,:)));
                    accuracy = (success/k)*100;                
                    
                    text_2 = uicontrol(f,'Style', 'text', 'String',strcat('Total samples = ',sprintf(" %d", total_test_points)),...
                    'Position', [350 415 300 30], 'FontSize', 11, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
          
                    text_3 = uicontrol(f,'Style', 'text', 'String',strcat('Number of samples classified correctly = ',sprintf(" %d", success)),...
                    'Position', [350 385 350 30], 'FontSize', 11, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
                        
                    text_4 = uicontrol(f,'Style', 'text', 'String',strcat('Accuracy = ',sprintf(" %0.2f", accuracy)),...
                    'Position', [350 355 300 30],'FontSize', 11, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
                     
                
                     try
                         %Text fields
                        text_5 = uicontrol(f,'Style', 'text', 'String',strcat('Sample Number   = ',sprintf(" %d", k)),...
                        'Position', [750 415 300 30],'FontSize', 11, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
                     
                        text_6 = uicontrol(f, 'Style', 'text', 'String',strcat('Actual Class          =              ',class),...
                        'Position', [750 385 300 30],'FontSize', 11, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
                      

                        if(sum(labels(k,:) == (readdata == max(readdata))) == 4)
                            color_string = "g";
                        else
                            color_string = "r";
                        end
                        text_7 = uicontrol(f, 'Style', 'text', 'String',strcat('Predicted Class    =               ',pred_class),...
                        'Position', [750 355 300 30], 'FontSize', 11, 'FontWeight', 'bold', 'HorizontalAlignment', 'left','ForegroundColor',color_string);
                        
                        text_8 = uicontrol(f, 'Style', 'text', 'String','Predicted Class    = ',...
                        'Position', [750 355 140 30], 'FontSize', 11, 'FontWeight', 'bold', 'HorizontalAlignment', 'left');
                       

                        % Bar chart
                        X = categorical({'Audio Left', 'Audio Right', 'Visual Left', 'Visual Right'});
                        X = reordercats(X,{'Audio Left', 'Audio Right', 'Visual Left', 'Visual Right'});
                        Y = ((readdata - output_zero_point) * output_scale)*100;
                        [Max,Index] = max(Y);                   

                        if(k~=1)
                            set(bb, 'visible', 'off');
                            set(ax1, 'visible', 'off');
                        end
                        ax1 = axes(f, 'Position',[0.3 0.2 0.6 0.3]);
                        bb = bar(ax1,X, Y,'FaceColor','flat');
                        bb.CData(Index,:) = [0 0.8 0.8];
                        ylim([0 100]);

                     catch
                        disp("Figure is closed");
                        break;
                    end 
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%<<<<<<GUI code ends here>>>>>>%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                     k=k+1;
                end
                break;
            end
        end
    end

    %Print the over all Accuracy
    fprintf("\n\nClassification accuracy = %f\n",success/length(labels));
    clear device;
end